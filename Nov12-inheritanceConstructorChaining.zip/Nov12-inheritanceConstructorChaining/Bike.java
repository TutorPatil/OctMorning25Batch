package com.corejava.oops.inheritance;

public class Bike extends Vehicle{

    public Bike()
    {
        System.out.println("Inside the bike constructor..");
    }
    public   void putStand()
    {
        System.out.println(" The Bike of the colour "+colour+
                " is Automatic " + isAutomatic +
                " can be parked by using the stand");
    }

    public void drive()
    {
        System.out.println(" The Bike  of the colour "+colour+
                " which has "+noOfWheels +" wheels" + " is automatic "+isAutomatic +
                " has to be driven with proper balance .....");

    }

    public static void testStatic()
    {
        System.out.println(" inside the static method of the Bike  class");
    }


}
