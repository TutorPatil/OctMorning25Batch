package com.corejava.oops.inheritance;

public class Car extends Vehicle{

    public Car()
    {
        System.out.println("Inside the car constructor..");
    }

        public void reverseDrive()
        {
            System.out.println(" The car of the colour "+colour+
                    " is Automatic "+isAutomatic+
                    " Can be driven in reverse direction");
        }
// Changing the implementation or body of the inherited method
// in the child class ->Method overriding

    public void drive()
    {
        System.out.println(" The Car of the colour "+colour+
                " which has "+noOfWheels +" wheels" + " is automatic "+isAutomatic +
                " is been driven smootly.....");

    }

    public static void testStatic()
    {
        System.out.println(" inside the static method of the Car  class");
    }

//    // final methods cant be overridden
//    public final void  useFuelForDrive()
//    {
//        System.out.println(" You need to use fuel for drive...");
//    }

}
