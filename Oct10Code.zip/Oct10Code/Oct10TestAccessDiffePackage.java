package com.test1;

import com.corejava.practice.Oct10AccessControllers;

public class Oct10TestAccessDiffePackage {


    public static void main(String[] args) {

        System.out.println(Oct10AccessControllers.country);


    }
}
