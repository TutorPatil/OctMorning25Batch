package com.corejava.practice;

public class Oct10TestAccess {


    public static void main(String[] args) {

        Oct10AccessControllers obj1 = new Oct10AccessControllers();
        System.out.println(obj1.y);  //  y is having default access controller - i.e package level access


    }
}
