package com.classesobjects;

public class TestStudent {


    public static void main(String[] args) {


        Address_Nov6 a1 = new Address_Nov6();
            a1.flatNo = 150;
            a1.streetName = "MG road";
            a1.area = "Kacheguda";
            a1.pinCode = 560010;
            a1.state = "Telangana";

        Student s =  new Student();
            s.id = 15;
            s.name = "Rohit";
            s.standard = 8;
            s.transportOpted = true;
            s.a = a1;


        System.out.println(s.getStudentDetails());
        System.out.println(s.getStudentNameAndAddress());




    }


}
