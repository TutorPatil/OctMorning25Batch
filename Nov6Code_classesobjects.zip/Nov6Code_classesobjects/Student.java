package com.classesobjects;

public class Student {

    int id;
    String name;
    int standard;
    boolean transportOpted;
    Address_Nov6 a;

    public Student()
    {
        System.out.println(" Inside Student class constructor");
    }

    public Student(int a, String s, int b,boolean b1,Address_Nov6 a1)
    {
        id = a;
        name =s;
        standard=b;
        transportOpted=b1;


    }

    public String getStudentDetails() {
        int x = 10;
        String details = "Student Name is " + name + " Roll num is " + id + " studying in  " + standard;
        return details;
    }

    public String getStudentNameAndAddress()
    {
        String details = "";
        details = "Name "+name+ "Address "+ a.getAddressDetails();

        return details;
    }

}
