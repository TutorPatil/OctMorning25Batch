package com.classesobjects;

public class Address_Nov6 {

    int flatNo;
    String streetName;
    String area;
    int pinCode;
    String state;
    static String country = "India";

    public String getAddressDetails()
    {
        String details = "";
            details = "Flat no "+flatNo+" street "+streetName+"Area "+area+"Pincode "+pinCode+" state "+state+" country "+country;
        return details ;
    }



}
