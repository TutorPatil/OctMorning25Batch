package com.classesobjects;

public class Student {

    int id;
    public String name;
    int standard;
    boolean transportOpted;
    Address_Nov6 a;

    public Student()
    {
       System.out.println(" Inside Student class constructor");
    }

    public Student(int a, String s, int b,boolean b1, Address_Nov6 a1)
    {
        id = a;
        name =s;
        standard=b;
        transportOpted=b1;
    }

    public Student(int i, String ramu, int i1, boolean b) {
        id=i;
        name=ramu;
        standard=i1;
        transportOpted=b;
    }

    public String getStudentDetails() {
        int x = 10;
        String details = "Student Name is " + name + " Roll num is " + id + " studying in  " + standard;
        return details;
    }

    public String getStudentNameAndAddress()
    {
        String details = "";
        details = "Name "+name+ "Address "+ a.getAddressDetails();

        return details;
    }

    public String toString()
    {
        return ""+id+" "+name+" "+standard+" "+transportOpted;
    }

}
