package com.classesobjects;

public class CarEngine {

    int engineCC;
    String manufacturer ;
    boolean needsCoolent ;
    static int size = 10;

    public void keepEngineCool()
    {
        System.out.println(" Make sure the egine of cc "+ engineCC +
                "Manufactured by "+ manufacturer + " is always kept cool...");
    }


}
