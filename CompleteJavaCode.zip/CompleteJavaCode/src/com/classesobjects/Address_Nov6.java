package com.classesobjects;

public class Address_Nov6 {

  public   int flatNo;
    public  String streetName;
    public  String area;
    public  int pinCode;
    public  String state;
    public static String country = "India";

    public String getAddressDetails()
    {
        String details = "";
            details = "Flat no "+flatNo+" street "+streetName+"Area "+area+"Pincode "+pinCode+" state "+state+" country "+country;
        return details ;
    }



}
