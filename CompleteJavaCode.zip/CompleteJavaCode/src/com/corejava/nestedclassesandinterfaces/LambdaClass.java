package com.corejava.nestedclassesandinterfaces;

public class LambdaClass {


    public static void main(String[] args) {

        Test t = (a,b)-> System.out.println(a+b);
        t.addNumbers(10,20);

        Test2 t2 = (a,b)-> (a+b);
        System.out.println(t2.addNumbers(100,200));

        Test3 t3 = name -> "Welcome "+name;
        System.out.println(t3.getNameAndGreetWelcome("Rakesh"));

        Test3 t31 = new Test3() {

            public String getNameAndGreetWelcome(String name) {
                return "Welcome "+name;
            }
        };

        class Test123 implements Test3{

            public String getNameAndGreetWelcome(String name) {
                return "Welcome "+name;
            }
        }
        Test123 t32 = new Test123();
        System.out.println(t32.getNameAndGreetWelcome("Rahman"));


        System.out.println(t31.getNameAndGreetWelcome("Rakesh"));

        Test4 t4  = (sal, comm) -> {
            System.out.println(" Your sala + comm is "+ (sal+comm));
            if ((sal + comm) > 10000)
                return  2000;
            else
                return 1000;
        };



       int bonus =  t4.getSalaryAndComissionAndFindBonus(15000,2000);
        System.out.println(bonus);


    }

    interface Test3{
        String getNameAndGreetWelcome(String name);
    }

    interface Test4{
        int getSalaryAndComissionAndFindBonus(int sal, int com);
    }



    interface Test{
        public abstract void addNumbers(int a, int b);
    }

    interface Test2{
         int addNumbers(int a, int b);
    }







}
