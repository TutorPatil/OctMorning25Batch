package com.corejava.nestedclassesandinterfaces;

public class Outer {

    int outerAge = 10;
    static String state = "Karnataka";

    public void printOuterAge()
    {
        System.out.println("Outer age is "+outerAge);
        Inner in = new Inner();
        System.out.println(in.innerAge);
       // in.printInnerAge();

        InnerPrivate inPvt = new InnerPrivate();
        System.out.println(inPvt.pvtAge);

        Outer.InnerStatic.printCountry();
        System.out.println(Outer.state);
    }

    public static void main(String[] args) {
        Outer out = new Outer();
        out.printOuterAge();
        Inner in = out.new Inner(); // as the inner class is non static
    }

    class Inner{

        int innerAge = 15;

        public void printInnerAge()
        {
            System.out.println("Inner age is "+innerAge);
            System.out.println(outerAge);
            printOuterAge();
        }
    }

    private class InnerPrivate{

        int pvtAge = 20;

        void testPvt(){
            System.out.println(outerAge);
            printOuterAge();
        }
    }

    static class InnerStatic{

        int staticAge = 25;
        static String country = "India";

        static void printCountry()
        {
            System.out.println(country);
            System.out.println(state);
        }


    }



}
