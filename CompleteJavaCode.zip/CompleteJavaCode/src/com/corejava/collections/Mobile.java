package com.corejava.collections;

import java.util.*;

public class Mobile implements Comparable<Mobile>{

    int ram;
    String colour;
    String company;
    boolean wireLessCharingSupported;

    public Mobile(int ram, String colour, String company, boolean wireLessCharingSupported) {
        this.ram = ram;
        this.colour = colour;
        this.company = company;
        this.wireLessCharingSupported = wireLessCharingSupported;
    }


    public String toString() {
        return "Mobile{" +
                "ram=" + ram +
                ", colour='" + colour + '\'' +
                ", company='" + company + '\'' +
                ", wireLessCharingSupported=" + wireLessCharingSupported +
                '}';
    }

    public static void main(String[] args) {

        Mobile m1 = new Mobile(8,"Black","Samsung",true);
        Mobile m2 = new Mobile(24,"White","Nokia",false);
        Mobile m3 = new Mobile(16,"Blue","Apple",true);
        Mobile m4 = new Mobile(32,"Red","Oppo",false);


        PriorityQueue<Mobile> mq = new PriorityQueue<>();
            mq.add(m1);
            mq.add(m2);
            mq.add(m3);
            mq.add(m4);


        System.out.println(mq.poll());
        System.out.println(mq.poll());
        System.out.println(mq.poll());
        System.out.println(mq.poll());

        List<Mobile> mobiles = new ArrayList<>();
            mobiles.add(m1);
            mobiles.add(m2);
            mobiles.add(m3);
            mobiles.add(m4);


        Comparator1 comp1 = new Comparator1();

        Comparator<Mobile> comp = new Comparator<Mobile>() {

            public int compare(Mobile o1, Mobile o2) {
                if (o1.ram > o2.ram)
                    return -1;
                else
                    return 1;
            }
        };

        System.out.println(mobiles);
        //Collections.sort(mobiles,comp);
        Collections.sort(mobiles);
        System.out.println(mobiles);

       // Collections.sort(mobiles);


    }

    public int compareTo(Mobile o) {
        if(this.ram > o.ram)
            return -1;
        else
            return 1;
    }



    Test t1 = new Test() {

        public int addNumbers(int a, int b) {
            return (a+b);
        }
    };


    interface Test{
        int addNumbers(int a, int b);
    }

    class Test1 implements Test{

        public int addNumbers(int a, int b) {
            return (a+b);
        }
    }
}
