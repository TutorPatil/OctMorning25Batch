package com.corejava.finalsession;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class ForEachMethodOnCollections {


    public static void main(String[] args) {

        // To create a list
        List<Integer> al = List.of(15,23,8,11,4,27,18);

        Stream<Integer> s = al.stream();
         //s.forEach(n-> System.out.println(n));
        // s.forEach(n-> System.out.println(n)); // Stream once consumed cant be reused..

        Stream<Integer> s1 = s.filter(e -> e % 2 == 0);
       // s1.forEach(n-> System.out.println(n));

        // Using Map method to double the numbers in stream
        Stream<Integer> s2 = s1.map(n-> n*n);
        //s2.forEach(n -> System.out.println(n));

        // to Sort the steam
        Stream<Integer> s3 = s2.sorted();
        //s3.forEach(n-> System.out.println(n));

       Integer result =  s3.reduce(0,(a,b)->a+b);

        System.out.println(result);



        List<Integer> al2 = List.of(15,23,28,11,4,27,18);

      Integer r =    al2.stream()
                    .filter(n -> n % 2 == 0)
                    .map(n -> n*n)
                    .sorted()
                    .reduce(0,(a,b)->a+b);

        System.out.println(r);

        List<Integer> al3 = List.of(15,23,28,11,4,27,18);

        al3.stream()
                .filter(n -> n % 2 == 0)
                .map(n -> n*n)
                .sorted()
                .reduce(0,(a,b)->a+b);


    }


    public static void forEachMethodOnCollections(){
        // For each method for List

        // To create a list
        List<Integer> al1 = List.of(15,25,8,16,4,2,18);


        List<Integer> al = Arrays.asList(10, 5, 16, 8, 18, 25);
        al.forEach(n-> System.out.println(n));

        List<String> al2 = Arrays.asList("Selenium","Java","Automation");
        al2.forEach(System.out::println); // Method referrence

        // Regual for loop using index
        for(int x = 0; x<al2.size(); x++){
            System.out.println(al2.get(x));
        }
        // enhanced for loop (for each loop)
        for(String m :al2)
        {
            System.out.println(m);
        }

        // for each method..
        al2.forEach(n-> System.out.println(n));

        System.out.println("************************");

        // For each method for Set
        Set<String> set = Set.of("Java", "Selenium", "Automation"); // to create a set
        set.forEach(n-> System.out.println(n));


        // creating Map and using for each method...
        Map<Integer,String> hm = new HashMap<>();
        Map<Integer,String> hmap = Map.of(1,"java",2,"automation",3,"selenium");

        hmap.forEach((k,v)-> System.out.println(k+"->"+v));



    }



}
