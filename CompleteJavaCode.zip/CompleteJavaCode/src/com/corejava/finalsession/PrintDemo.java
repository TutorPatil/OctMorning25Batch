package com.corejava.finalsession;

public class PrintDemo <T> {

    T toPrint;


    public PrintDemo(T toPrint) {
        this.toPrint = toPrint;
    }

    public void print()
    {
        System.out.println(toPrint);
    }

    public <T> void getData(T data)
    {
        System.out.println("dadd");
    }
}
