package com.corejava.finalsession;

public class EnumExamples {

    enum  Color {
        RED,
        GREEN,
        BLUE
    };

    enum Days {
        MONDAY,
        TUESDAY,
        WEDNESDAY,
        THURSDAY,
        FRIDAY,
        SATURDAY,
        SUNDAY
    };


    enum StatusCode{
        Success,
        Failure
    };


    public static void main(String[] args) {

        Days d = Days.TUESDAY;
        System.out.println(d);
        System.out.println(d.ordinal());
        Days[] darr = Days.values();

        if (d == Days.MONDAY) {
            System.out.println(" Week started...");
        }
        else
        {
            System.out.println(" Week started yesterday itself... ");
        }


        StatusCode c = StatusCode.Success;
        if(c == StatusCode.Success) {
            System.out.println("Success");
        }
    }


}
