package com.corejava.constructors;


import com.classesobjects.Address_Nov6;

public class Student {

    String name;
    int standard;
    boolean transportOpted;
    Address_Nov6 a;
    int id;

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStandard(int standard) {
        this.standard = standard;
    }

    public void setTransportOpted(boolean transportOpted) {
        this.transportOpted = transportOpted;
    }

    public void setA(Address_Nov6 a) {
        this.a = a;
    }



    public Student(int id, String name, int standard, boolean transportOpted, Address_Nov6 a) {
        if ( id != 0 )
            this.id = id;

        this.name = name;
        this.standard = standard;
        this.transportOpted = transportOpted;
        this.a = a;
    }
    public Student(int id, String name, int standard, boolean transportOpted) {
        this.id = id;
        this.name = name;
        this.standard = standard;
        this.transportOpted = transportOpted;

    }

    // Constructor - default
    public Student()
    {
        System.out.println("Student constructor");
    }



    public void getStudentDetails()
    {
        System.out.println(" The details  student with name "+ name +
                "who has id "+ id + " studying in std "+ standard);
    }


}
