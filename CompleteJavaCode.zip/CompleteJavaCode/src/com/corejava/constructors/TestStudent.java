package com.corejava.constructors;

import com.classesobjects.Address_Nov6;

public class TestStudent {

    public static void main(String[] args) {

        // The constructor is a method like entity
        // Name of the constructor is same as the name of the class
        // It may or may not take arguments
        // It will not have any return type
        // It is invoked when ever object of the class is created
        // The default constructor is added by the compiler if it is not present

        Student s = new Student();
        s.id = 1;
        s.name = "John";
        s.standard = 5;
        s.transportOpted = true;

        s.getStudentDetails();

        Student s2 = new Student(20,"Peter",8,false);
        s2.getStudentDetails();

        Student s3 = new Student(25,"Rahul",7,true);
        s3.getStudentDetails();

        Address_Nov6 a1 = new Address_Nov6();
        a1.flatNo = 100;
        a1.streetName = "MG Road";
        a1.area = "JayaNagar";

        Student s4 = new Student(50,"Rakesh",4,true,a1);
        s4.getStudentDetails();






    }

}
