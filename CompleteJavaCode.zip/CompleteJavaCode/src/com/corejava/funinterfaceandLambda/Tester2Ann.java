package com.corejava.funinterfaceandLambda;

public class Tester2Ann {

    public static void main(String[] args) {


        Test2 t = new Test2() {

            public int squareNumber(int x) {
                return (x * x);
            }
        };
        System.out.println(t.squareNumber(6));
        System.out.println("=====================");

        Test2 t1 =x -> (x * x);

        System.out.println(t1.squareNumber(8));


    }
}
