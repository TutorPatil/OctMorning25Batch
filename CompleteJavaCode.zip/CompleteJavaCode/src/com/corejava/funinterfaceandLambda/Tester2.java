package com.corejava.funinterfaceandLambda;

public class Tester2 {

    public static void main(String[] args) {

        //Test2Impl t = new Test2Impl();
        Test2 t = new Test2Impl();
        System.out.println(t.squareNumber(5));

    }
}
