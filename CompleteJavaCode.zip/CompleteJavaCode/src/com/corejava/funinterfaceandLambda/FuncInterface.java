package com.corejava.funinterfaceandLambda;

@FunctionalInterface
public interface FuncInterface {

     int addNumbers(int a, int b);
}
