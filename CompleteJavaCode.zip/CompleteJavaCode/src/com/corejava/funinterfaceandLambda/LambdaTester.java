package com.corejava.funinterfaceandLambda;

public class LambdaTester {


    public static void main(String[] args) {
       // StringLenInterface t = name -> System.out.println("Welcome" + name);
       // t.getNameAndPrint("Patil");

        StringLenInterface t1 = (name) -> {
            System.out.println(" We are in lambda");
            System.out.println(" Your name is "+ name);
            return name.length();
        };
        System.out.println(t1.getNameAndFindLength("Patil"));

        StringLenInterface t2 = (name) -> name.length();
        System.out.println(t2.getNameAndFindLength("Ramu"));










    }

}
