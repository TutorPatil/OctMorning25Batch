package com.corejava.funinterfaceandLambda;

@FunctionalInterface
public interface LambdaAdd {

    public abstract int addNumbers( int x, int y);

}
