package com.corejava.exceptions;

public class RecursionExample {

    public static void main(String[] args) {

        int fact =  findFactorial(4);
        //System.out.println(fact);

        //int sum = sumOfDigits(1234);
        //System.out.println(sum);


        int val = fibonacci(6);

        System.out.println(val);


    }

    public static void showNumbers(int num)
    {
        System.out.println(num);

        if(num > 0)  // Base case
            showNumbers(num-1);

    }

    public static void showNumbers2(int num)
    {
          if(num > 1) // Base case
              showNumbers2(num-1);
        System.out.println(num);

    }

    public static int findFactorial(int num)
    {
        if(num == 1)
            return 1;

        return num * findFactorial(num -1);
    }
/*
    public static int   (int num)
    {
        if(num ==0)
            return 0;

        return num%10 + sumOfDigits(num/10);

    }
*/
    public static int fibonacci(int n) {
        if (n == 0) return 0;      // Base case
        if (n == 1) return 1;      // Base case

        return fibonacci(n - 1) + fibonacci(n - 2); // Recursive calls
    }


}
