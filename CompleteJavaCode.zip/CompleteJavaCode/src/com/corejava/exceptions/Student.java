package com.corejava.exceptions;

public class Student {

    String name;
    int age;


    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void getAdmission() throws InvalidAgeException {
        if ( age > 6)
        {
            System.out.println(" The student "+name + " is eligible for Admission");
        }
        else
        {
                InvalidAgeException ia = new InvalidAgeException("Age is less than 6 and student not allowed for admssion");
                throw ia;
        }
    }


}
