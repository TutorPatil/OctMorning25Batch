package com.corejava.practice;

public class Sample {
    static int empId = 150;
    static String empName = "Rakesh";

    public static void main(String[] args) {
        System.out.println("Welcome to Java");
        System.out.println("Java is very simple");
        System.out.println(empId);
        System.out.println(empName);
        System.out.println("==================");
        testMethod();
    }

    public static void testMethod()
    {
        System.out.println("Inside the testMethod");
        System.out.println(empName);
    }


}
