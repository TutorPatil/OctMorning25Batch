package com.corejava.practice;

public class Oct10LocalGlobalScope {
    static int x;
    static String s = "java";
    static boolean  b ;
    static double d;


    public static void main(String[] args) {
        int y ;
        y = 10; // local variables must be initialized they will not carry any default values

        System.out.println(y);

        System.out.println(x);
        System.out.println(b);
        System.out.println(d);


    }






}
