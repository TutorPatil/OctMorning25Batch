package com.corejava.practice;

public class Oct10AccessControllers {
    private static  int x = 10; // private access controller , can be used with in the class
    int y = 20; // default access controller can be used with in the clas and with in the package
    public static String country = "India";
    protected int passcode = 1234;
    private int pinNum = 1234;



    public static void main(String[] args) {
        System.out.println(x);

        Oct10AccessControllers obj = new Oct10AccessControllers();
        System.out.println(obj.y);
        System.out.println(obj.passcode);

        System.out.println(country);


    }



}
