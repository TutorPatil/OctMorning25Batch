package com.corejava.practice;

public class Oct10IncrementDecrement {

    public static void main(String[] args) {
        characterLiterals();
    }

    public static void incrementDecrementOperators()

    {
        int x = 10;
        //int y = ++x;
        //int y = x++;
        //int y  = --x;
        //int y = x--;


        //System.out.println(x);
       // System.out.println(y);

        //int z = 10++; // can't use increment / decrement operators with literals.

/*
        for (int i=1; i<=10; i++)
        {
            System.out.println(i);

        }

*/


    }



    public static void characterLiterals()
    {
        //String s = "Selenium\nAutomation";  // New line character

       // String s = "Selenium\tAutomation"; // Horizontal Tab

     // String s = "Selenium\" Automation";  // double quotes
       // String s = "c:\\programfiles\\java";

        //System.out.println(s);


    }
}
