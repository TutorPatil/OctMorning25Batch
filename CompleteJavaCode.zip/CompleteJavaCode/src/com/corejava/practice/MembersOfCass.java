package com.corejava.practice;

public class MembersOfCass {
    static int age = 20;
    boolean isMarried = false;
    char countryCOde = 'I';
    static double marks = 85.5;
    static String name = "Rakesh";
    String country = "India";  // String country = new String("India");


    public static void main(String[] args) {
        System.out.println("Inside the main method starting....");
        System.out.println(age);
        age = 25;
        System.out.println(age);
        testStatic();
        System.out.println(age);
        int y = 25; // x is local variable of main method
        System.out.println("The value of local variable x of main method is.."  +y);
        MembersOfCass m = new MembersOfCass();  // Creating an instance or Object of the class to access non static members
        //System.out.println(m.countryCOde);
        //m.testNonStatic();
        System.out.println(name);
        System.out.println("Ending the main method...");
    }

    public static void testStatic()
    {
        System.out.println(" Inside the test Static method...");
        int x = 30;
        System.out.println(" The value of x is "+x);
        System.out.println(age);
    }
    

}
