package com.corejava.practice;

import com.classesobjects.Student_Nov5;

public class DataTypes {

    static int personAge = 30;
    static int deptNumber = 25;
    static int pincode = 560001;

    static byte b = 10;
    static byte b1 = 125;
    short s = 130;
    short s1 = 20000;
    long l1= 10;
    long l2 = 154514542552L;

    double d = 10.52;
    float f = 10.25F;


    char c = 'a';
    char c1 = 'x';

    boolean bool = true;
    boolean isMarried = true;
    boolean isEnabled = false;






    public static void main(String[] args) {
       //  System.out.println(personAge);
         System.out.println(b1);
     /*   System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);
     */
       System.out.println(Integer.max(10,20));

        char c = 'a';
        System.out.println(c);

        char c1 = 97;

        System.out.println(c1);

        int x = 'a';

        System.out.println(x);

        System.out.println(Byte.MAX_VALUE);

        byte b = (byte)130;

        System.out.println(b);



    }


}


