package com.corejava.practice;

import org.w3c.dom.ls.LSOutput;

public class SampleClass {

    public static void main(String[] args) {
        int[] x = {10,30,15,16,18,25};

        int[] y = {200,150,36,20,32};

        int big = Integer.MAX_VALUE;
        int small = Integer.MIN_VALUE;

        for(int m:x){

//            if(m < small)
//                 small = m;
//
//            if( m > big  )
//                big = m;

            if(m > small)
                small = m;

            if( m < big)
                big = m;


        }

        System.out.println("Smallest num is "+big+ "Biggest num is" + small);


    }







}
