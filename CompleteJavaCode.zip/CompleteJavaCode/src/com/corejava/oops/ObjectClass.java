package com.corejava.oops;

public class ObjectClass {

    public static void main(String[] args) {

        Car c = new Car();
        c.setGear(4);
        c.setColour("Blue");
        c.setFuelType("Petrol");
        c.setSpeed(150);

        c.driveCar();

        Car  c1 = new Car();
        c1.setSpeed(150);

       // Object obj = new Car();
       // ((Car)obj).driveCar();

        System.out.println("... Object Class Methods....");

        System.out.println(c.getClass());

        System.out.println(c.hashCode());

        System.out.println(c1.hashCode());

        System.out.println(c.toString());

        System.out.println(c);

        BankAccount b = new BankAccount();
        System.out.println(b);
        System.out.println(b.toString());


        System.out.println(c.equals(c1));

        String s = "Selenium";
        System.out.println(s.hashCode());

        String s1 = new String("selenium");
        System.out.println(s1.hashCode());

        System.out.println(s);
        System.out.println(s.toString());

        System.out.println(s1);
        System.out.println(s1.toString());

        System.out.println(s.equals(s1));

    }


}
