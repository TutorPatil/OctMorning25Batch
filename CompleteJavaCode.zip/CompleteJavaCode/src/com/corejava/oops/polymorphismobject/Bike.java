package com.corejava.oops.polymorphismobject;

public class Bike implements  Vehicle{

    public void drive() {
        System.out.println(" The Bike can be driven ....");
    }

    public void fillFuel() {
        System.out.println(" The Bike can be also parked....");
    }

    public void putStand()
    {
        System.out.println(" The bike can be parked using stand...");
    }
}
