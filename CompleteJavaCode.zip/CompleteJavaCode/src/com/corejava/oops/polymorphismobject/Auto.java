package com.corejava.oops.polymorphismobject;

public class Auto implements  Vehicle{

    public void drive() {
        System.out.println(" The Auto can be driven ....");
    }

    public void fillFuel() {
        System.out.println(" The Auto can be also parked....");
    }

}
