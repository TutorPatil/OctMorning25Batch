package com.corejava.oops.polymorphismobject;

import java.util.Arrays;

public class TestVehicle1 {


    public static void main(String[] args) {

        Object[] strArray = {"Java","Selenium","Testing"};

        //int[] x = {10,20,30};
        Object[] x = {10,20,30};


        Vehicle c2 = new Car();
        ((Car)c2).driveReverse(); // down casting


        Object c3 = new Car();

        ((Car)c3).drive();
        ((Car)c3).driveReverse();
        ((Car)c3).fillFuel();





        addNumbers(10,20,"Java");
        //Car c = new Car();
        Object c1 = getVehicleObject("Car");
        driveVehicle(c1);

        //Bike b = new Bike();
        Object b1 = getVehicleObject("Bike");
        driveVehicle(b1);


        System.out.println(getStringLength("java"));



    }
    public static void addNumbers(int a, int b,String s)
    {
        int sum = (a+b);
        int len = s.length();
        char[] c=  s.toCharArray();
        System.out.println(len);
        System.out.println(sum);
        System.out.println(Arrays.toString(c));
    }

    public static void driveVehicle(Object v)
    {
        ((Car)v).drive();
    }

    public static int getStringLength(String s)
    {
        int len = s.length();
        return len;

    }

    public static Object getVehicleObject(String objType)
    {
        Vehicle v = null;

        if( objType.equalsIgnoreCase("Car")) {
            v = new Car();
        }
        if( objType.equalsIgnoreCase("Bike")) {
            v = new Bike();
        }

        return v;

    }


}
