package com.corejava.oops;

public class TestBankAccount {

    public static void main(String[] args) {

        BankAccount b1 = new BankAccount();
        System.out.println(" Initial balance "+ b1.getBalance());

        b1.withDraw(5000);

        System.out.println(" Post Wihdrawal "+b1.getBalance());

        b1.deposit(25000);
        System.out.println(" After depositing "+ b1.getBalance());

    }
}
