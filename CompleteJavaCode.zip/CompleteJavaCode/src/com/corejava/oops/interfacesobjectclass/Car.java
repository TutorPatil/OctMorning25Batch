package com.corejava.oops.interfacesobjectclass;

public class Car extends  Vehicle implements Taxi , PlayToy{
    String fuelType;


    public void fillFuel() {
        System.out.println(" The car of the colour "+ color +
                "of type automatic "+isAutomatic + " which has no of seats "+noOfSets +
                " needs "+fuelType+"  to be filled for drive");
    }

    public void drive()
    {
        System.out.println(" The Car of the colour "+
                color + " which has "+noOfSets +"seats "+
                "which is Automatic "+isAutomatic +" can be driven" );
    }


    public void offerDrive() {
        System.out.println(" The car of the colour "+ color +
                "of type automatic "+isAutomatic + " which has no of seats "+noOfSets +
                " needs "+fuelType+" can be used as a Taxi to offer rides.. ");
    }


    public void startDrive() {
        System.out.println(" The car of the colour "+ color +
                "of type automatic "+isAutomatic + " which has no of seats "+noOfSets +
                " needs "+fuelType+" can start the ride as Taxi");
    }


    public void endDrive() {
        System.out.println(" The car of the colour "+ color +
                "of type automatic "+isAutomatic + " which has no of seats "+noOfSets +
                " needs "+fuelType+" can end the ride as Taxi");
    }

    public void canPlayUsingBattery() {
        System.out.println( " The car can also be used as a Toy....and palyed using Battery..");
    }

    public void canJumpAndMakeSound() {
        System.out.println( " The car can also be used as a Toy it makes sound and jumps..");
    }


    public void checkIdentityBeforeDrive() {
        System.out.println(" The car Taxi must check identity before the drive.....");
    }


    public void offerFreeFirstRide() {
          System.out.println(" The first ride for the car Taxi is free for every customer...");
    }

    
}




