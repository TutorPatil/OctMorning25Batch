package com.corejava.oops.interfacesobjectclass;

public interface StateTaxi {

        void offerFreeFirstRide();

}
