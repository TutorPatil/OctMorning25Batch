package com.corejava.oops.interfacesobjectclass;

public interface Taxi extends GovtTaxi ,StateTaxi {

    public static final String permitState = "karanataka";

    public abstract void offerDrive();

    void startDrive();
    void endDrive();


}
