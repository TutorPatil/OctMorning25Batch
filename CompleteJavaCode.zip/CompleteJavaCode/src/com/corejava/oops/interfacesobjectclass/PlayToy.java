package com.corejava.oops.interfacesobjectclass;

public interface PlayToy {


    public abstract  void canPlayUsingBattery();
    void canJumpAndMakeSound();



}
