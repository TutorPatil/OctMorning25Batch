package com.corejava.oops.interfacesobjectclass;

public interface GovtTaxi {

    public abstract void checkIdentityBeforeDrive();

}
