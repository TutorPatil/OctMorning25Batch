package com.corejava.oops;

import java.io.File;
import java.io.IOException;

public class FileHandling {


    public static void main(String[] args) throws IOException {

        File f = new File("D:\\test");
        f.mkdir();

        System.out.println(f.getAbsolutePath());

        System.out.println(f.isDirectory());

        System.out.println(f.exists());

        System.out.println(f.getName());
        System.out.println(f.getParent());

        File f1 = new File("D:\\test\\sample.txt");
        f1.createNewFile();
        System.out.println(f1.isDirectory());
        System.out.println(f1.isFile());

        String[] files = f.list();

        for(String m:files){
            {
                System.out.println(m);
            }
        }



    }
}
