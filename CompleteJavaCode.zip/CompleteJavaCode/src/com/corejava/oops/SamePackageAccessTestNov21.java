package com.corejava.oops;

public class SamePackageAccessTestNov21 {

    public static void main(String[] args) {
        System.out.println(Nov21AccessController.name);
        System.out.println(Nov21AccessController.protectedData);
        System.out.println(Nov21AccessController.country);

    }
}
