package com.corejava.oops.superkeyword;

public class Vehicle {
    String colour;
    int noOfheels;


    public Vehicle(String colour, int noOfheels) {
        this.colour = colour;
        this.noOfheels = noOfheels;
    }

    public Vehicle()
    {

    }



    public void drive()
    {
        System.out.println(" The vehicle of the color "+colour +
                "which has  "+noOfheels +" wheels is been driven..");

    }





}
