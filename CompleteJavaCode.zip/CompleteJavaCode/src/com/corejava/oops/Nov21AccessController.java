package com.corejava.oops;

public class Nov21AccessController {

    private static int age = 15;
    static String name = "Ramu";
    protected static String protectedData = "Aadhar Number";
    public static String country = "India";


    public static void main(String[] args) {
        System.out.println(age);
        System.out.println(name);
        System.out.println(protectedData);
        System.out.println(country);


    }


}
