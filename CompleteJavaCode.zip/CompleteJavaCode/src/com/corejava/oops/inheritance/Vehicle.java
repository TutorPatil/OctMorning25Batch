package com.corejava.oops.inheritance;

public  class Vehicle {

    int noOfWheels;
    String colour ;
    boolean isAutomatic;

    public Vehicle() {
        System.out.println(" Inside the vehicle constructor..");
    }

    public void drive()
    {
        System.out.println(" The vehicle of the colour "+colour+
                " which has "+noOfWheels +" wheels" + " is automatic "+isAutomatic +
                " is been driven.....");

    }

    public static void testStatic()
    {
        System.out.println(" inside the static method of the vehicle class");
    }

    private void startUsingPassword()
    {
        System.out.println(" inside the private method...");
    }

    // final methods cant be overridden
    public final void  useFuelForDrive()
    {
        final int x = 10;
        // x=20; // final variables can't be modified
        System.out.println(" You need to use fuel for drive...");
    }





}
