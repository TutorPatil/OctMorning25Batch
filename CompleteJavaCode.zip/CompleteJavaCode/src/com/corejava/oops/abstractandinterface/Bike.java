package com.corejava.oops.abstractandinterface;

public class Bike implements Bikeinterface {

    public void drive() {
        System.out.println(" The Bike is been driven ");
    }

    public void park() {
        System.out.println(" The bike is been parekd...");
    }
}
