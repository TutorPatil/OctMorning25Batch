package com.corejava.oops.abstractandinterface;

public class TestBike {

    public static void main(String[] args) {

        Bike yamaha = new Bike();
            yamaha.drive();
            yamaha.park();
            System.out.println(" No of wheels are" + Bikeinterface.noOfWheels);

    }
}
