package com.corejava.oops.abstractandinterface;

public class Ford extends Car{

    public void drive() {
        System.out.println("Ford car of the color " +
                colour + " is Driven ");
    }


//    public void park() {
//        System.out.println("Ford car of the color " +
//                colour + " is Parked ");
//    }
}
