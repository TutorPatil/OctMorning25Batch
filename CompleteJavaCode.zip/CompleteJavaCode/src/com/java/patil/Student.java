package com.java.patil;

public class Student {

    int age;
    String name;


    public void setAge(int age) throws InvalidAgeException {
        if( age < 6)
        {
            throw new InvalidAgeException("Students less than 6 years can't be admitted to school..");
        }
        this.age = age;
    }


}
