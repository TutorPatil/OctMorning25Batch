package com.java.patil;

public class Vehicle {

    private String colour ;
    private boolean isAutomatic;


    public boolean isAutomatic() {
        return isAutomatic;
    }

    public void setAutomatic(boolean automatic) {
        isAutomatic = automatic;
    }



    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }


    public void drive()
    {
        System.out.println(" The vehicle of the colour "+colour+
                 " is automatic "+isAutomatic +
                " is been driven.....");
    }
}
