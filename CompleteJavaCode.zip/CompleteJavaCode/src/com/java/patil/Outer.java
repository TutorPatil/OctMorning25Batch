package com.java.patil;

public class Outer {

    int outerAge = 10;

    public void outerTest()
    {
        System.out.println("Inside the outer test method....");
        Inner in = new  Inner();
        System.out.println(in.innerAge);
    }

    class Inner{
        int innerAge = 5;

        public void innerTest   ()
        {
            System.out.println("Inside the Inner test method....");
            System.out.println("outerAge="+outerAge);
            outerTest();

        }
    }


    public static void main(String[] args) {
        Outer out = new Outer();
        out.outerTest();
        System.out.println(out.outerAge);
    }

}
