package com.java.patil;

public class Car extends Vehicle{

    private int noOfWheels;

    public int getNoOfWheels() {
        return noOfWheels;
    }

    public void setNoOfWheels(int noOfWheels) {
        this.noOfWheels = noOfWheels;
    }

    public void driveReverse()
    {
        System.out.println(" The car which has no of wheels as"+noOfWheels + " The car of the colour " +getColour()+
                "of the type automatic "+isAutomatic() +" can be driven in reverse direction");
    }


}
