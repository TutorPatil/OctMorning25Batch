package com.java.patil;

public class TestVehicle {

    public static void main(String[] args) {

        Car hondaCity = new Car();

        hondaCity.setNoOfWheels(4);
        hondaCity.setColour("red");
        hondaCity.setAutomatic(true);

        hondaCity.drive();
        hondaCity.driveReverse();













    }




}
