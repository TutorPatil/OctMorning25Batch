package com.java.patil;

public class TestCustomException {

    public static void main(String[] args) throws InvalidAgeException {

        // Student s = new Student();
        //s.setAge(5);

        // showNumbers(5);

        int fact = findFact(5);
        System.out.println(fact);

        int sum = sumDigits(123456789);
        System.out.println(sum);


        System.out.println(fibonacci(7));
    }

    public static void showNumbers(int num) {

        if (num > 0)
            showNumbers(num - 1);

        System.out.println(num + " ");
    }

    public static int findFact(int num) {

        if (num == 1)
            return 1;
        return ( num * findFact(num-1));
    }

    public static int sumDigits(int num)
    {
        if (num == 0)
            return 0;

        return num % 10 + sumDigits(num / 10);
    }


    public static int fibonacci(int n) {
        if (n == 0) return 0;      // Base case
        if (n == 1) return 1;      // Base case

        return fibonacci(n - 1) + fibonacci(n - 2); // Recursive calls
    }
}

