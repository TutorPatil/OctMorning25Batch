package com.test1;

import com.corejava.practice.Oct10AccessControllers;
import com.corejava.practice.Oct23Methods;

public class Oct10TestAccessDiffePackage {


    public static void main(String[] args) {

        System.out.println(Oct10AccessControllers.country);

        //Oct23Methods.addNumbers();

//        Oct23Methods obj = new Oct23Methods();
//        obj.addNumbers();


    }
}
