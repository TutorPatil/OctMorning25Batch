package com.corejava.oops;

public class Car {

    private int speed;
    private String colour;
    private String fuelType;
    private int gear;

    public int getGear() {
        return gear;
    }

    public void setGear(int gear) {
        if(gear == 1 ) {
            this.gear = gear;
            chageSpeedAsPerGear(gear);
        }
        else if (gear == 2 ) {
            this.gear = gear;
            chageSpeedAsPerGear(gear);
        }
        else if(gear == 3) {
            this.gear = gear;
            chageSpeedAsPerGear(gear);
        }
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        if( speed > 20 && speed < 200)
            this.speed = speed;
        else
            System.out.println("speed not supported!..");
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        if(colour != null)
            this.colour = colour;
        else
            System.out.println(" please enter colour !..");
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        if( fuelType.equalsIgnoreCase("Diesel" ) )
            this.fuelType = fuelType;
        else
            System.out.println(" please enter proper fuel type !..");
    }

    public void driveCar()
        {
            System.out.println(" The car of the color "+colour + " of the fuel type "+fuelType +
                    "Can be driven up the speed "+ speed);
        }

        private void chageSpeedAsPerGear(int gear)
        {
            if( gear == 1)
            {
                System.out.println(" The car can be driver  between speed of 20 - 30 KMS based on your gear selected ");
            }
            if( gear == 2)
            {
                System.out.println(" The car can be driver  betwee speed of 30 - 50 KMS");
            }
            if( gear == 3)
            {
                System.out.println(" The car can be driver  betwee speed of 50 - 80 KMS");
            }

        }


}
