package com.corejava.oops.inheritance;

public class TestVehicle {

    public static void main(String[] args) {

        Car honda = new Car();

        honda.colour = "Black";
        honda.isAutomatic = true;
        honda.noOfWheels = 4;

        honda.drive();
        honda.reverseDrive();

        System.out.println("======");

        Bike pulser = new Bike();
        pulser.noOfWheels = 2;
        pulser.isAutomatic = false;
        pulser.colour = "Red";
        
        pulser.drive();
        pulser.putStand();

        
        


    }


}
