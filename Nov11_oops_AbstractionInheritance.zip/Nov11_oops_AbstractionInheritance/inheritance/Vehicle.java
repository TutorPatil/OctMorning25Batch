package com.corejava.oops.inheritance;

public class Vehicle {

    int noOfWheels;
    String colour ;
    boolean isAutomatic;


    public void drive()
    {
        System.out.println(" The vehicle of the colour "+colour+
                " which has "+noOfWheels +" wheels" + " is automatic "+isAutomatic +
                " is been driven.....");
    }





}
