package com.corejava.oops.inheritance;

public class Bike extends Vehicle{

    public   void putStand()
    {
        System.out.println(" The Bike of the colour "+colour+
                " is Automatic " + isAutomatic +
                " can be parked by using the stand");
    }
}
