package com.corejava.oops.inheritance;

public class Car extends Vehicle{

        public void reverseDrive()
        {
            System.out.println(" The car of the colour "+colour+
                    " is Automatic "+isAutomatic+
                    " Can be driven in reverse direction");
        }

}
