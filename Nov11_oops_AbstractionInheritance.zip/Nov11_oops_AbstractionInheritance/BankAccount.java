package com.corejava.oops;

public class BankAccount {

    private int  balance = 10000;


    public  int getBalance() {
        return balance;
    }

    public void withDraw(int amount) {
        if(amount < balance) {
            System.out.println(" Please collect your cash ..of " + amount);
            updateBalanceOnWithdraw(amount);
        }
        else
            System.out.println(" You dont have sufficient balance....");
    }

    public void deposit(int amount) {
        System.out.println(" Thanks for depositing..."+amount);
        updateBalanceOnDeposit(amount);
    }

    private void updateBalanceOnWithdraw(int amount)
    {
        balance = balance - amount;
    }
    private void updateBalanceOnDeposit(int amount)
    {
        balance = balance + amount;
    }





}
