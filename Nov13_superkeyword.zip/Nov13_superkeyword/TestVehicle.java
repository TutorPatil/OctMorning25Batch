package com.corejava.oops.superkeyword;

public class TestVehicle {

    public static void main(String[] args) {

        Car c1 = new Car("Black",6,"white",4);

        Car c = new Car();
        c.noOfheels=4;
        c.colour = "white";
        c.drive();
        c.driveReverse();



    }
}
