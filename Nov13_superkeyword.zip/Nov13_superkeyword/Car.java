package com.corejava.oops.superkeyword;

public class Car extends Vehicle{

    String colour;
    int noOfheels;

    public Car(String colour, int noOfheels) {
        super("Black",6);
        this.colour = colour;
        this.noOfheels = noOfheels;
    }


    public Car(String parentColour, int parentNoOfheels, String colour, int noOfheels) {
        super(parentColour, parentNoOfheels);
        this.colour = colour;
        this.noOfheels = noOfheels;
    }

    public Car()
    {
        super();
    }

    public void driveReverse()
    {

        System.out.println(" The car of the color "+colour +
                " which has "+noOfheels +"wheels can be driven in reverse..");

        super.drive();

        System.out.println("Car class colour"+ colour);
        System.out.println(super.colour);
    }
    public void drive()
    {
        System.out.println(" The Car  of the color "+colour +
                "which has  "+noOfheels +" wheels is been driven..");

        //super.drive();
    }


}
