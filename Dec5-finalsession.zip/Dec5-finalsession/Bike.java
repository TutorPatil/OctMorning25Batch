package com.corejava.finalsession;

public class Bike {

    String color;

    Bike(String color) {
        this.color = color;
    }


    public String toString() {
        return "Bike{" +
                "color='" + color + '\'' +
                '}';
    }
}
