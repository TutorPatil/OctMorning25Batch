package com.corejava.finalsession;

public class TestGenerics {

    public static void main(String[] args) {


        PrintDemo<Integer> p = new PrintDemo<>(50);
        p.print();

        PrintDemo<String> p2 = new PrintDemo<>("Hello");
        p2.print();


        Bike b = new Bike("Black");
        System.out.println(b);

        PrintDemo<Bike> p3 = new PrintDemo<>(b);
        p3.print();

    }
}
