package com.corejava.oops;

import com.classesobjects.Student;

public class TestCar {

    public static void main(String[] args) {

        Car c1 = new Car();
        c1.setSpeed(100);
        //c1.speed = -100;
        // c1.colour = "red";
        c1.setColour("blue");
        //c1.fuelType = "Petrol";
        c1.setFuelType("Diesel");

        c1.driveCar();
        c1.setGear(2);
       // c1.chageSpeedAsPerGear(gear); // implementation is hidden from the user...

        System.out.println(c1.getSpeed());


        System.out.println("==============");

        Car c2 = new Car();
        c2.setSpeed(180);
        c2.setColour("red");
        c2.setFuelType("Petrol");
        c2.driveCar();

        System.out.println(c2.getSpeed());

        // Creating a car Array to store Car Objects
        Car[] cArray = new Car[2];
            cArray[0] = c1;
            cArray[1] = c2;

        Car[] cArr1 = {c1,c2};

        int[] x = {10,20,30};

        String[] s = new String[2];
        s[0] = "blue";
        s[1] = "red";

        Student s1 = new Student();
        Student s2 = new Student();

        Student[] sAray = {s1,s2};






    }
}
