package com.corejava.funinterfaceandLambda;

public class TestFuncInterface implements FuncInterface{

   public int addNumbers(int a, int b) {
        return ( a + b);
    }
}
