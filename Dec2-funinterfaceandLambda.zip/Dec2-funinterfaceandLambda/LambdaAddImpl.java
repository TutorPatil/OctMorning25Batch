package com.corejava.funinterfaceandLambda;

public class LambdaAddImpl implements LambdaAdd {

    public int addNumbers(int x, int y) {
        return ( x + y);
    }

    public static void main(String[] args) {

        LambdaAdd lt = new LambdaAddImpl();
        System.out.println(lt.addNumbers(10, 20));

        LambdaAdd lt1 = new LambdaAdd() {

            public int addNumbers(int x, int y) {
                return ( x + y);
            }
        };
        System.out.println(lt1.addNumbers(100, 200));

        LambdaAdd lt2 = ( x,  y) ->  ( x  + y);

        System.out.println( lt2.addNumbers(100, 250));




    }
}
