package com.corejava.funinterfaceandLambda;

@FunctionalInterface
public interface Test2 {

    public abstract int squareNumber(int x);


}
