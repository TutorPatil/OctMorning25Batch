package com.corejava.funinterfaceandLambda;

public class Test2Impl implements Test2 {

    public int squareNumber(int x) {
        return (x * x);
    }
}
