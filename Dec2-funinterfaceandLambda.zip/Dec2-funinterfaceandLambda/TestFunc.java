package com.corejava.funinterfaceandLambda;

public class TestFunc {

    public static void main(String[] args) {
        FuncInterface t = new TestFuncInterface();
        System.out.println(t.addNumbers(10,20));
    }

}
