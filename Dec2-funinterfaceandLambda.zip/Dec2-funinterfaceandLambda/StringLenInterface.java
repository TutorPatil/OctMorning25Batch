package com.corejava.funinterfaceandLambda;


@FunctionalInterface
public interface StringLenInterface {

   // public abstract void getNameAndPrint(String name);

    public abstract int getNameAndFindLength(String name);


}
