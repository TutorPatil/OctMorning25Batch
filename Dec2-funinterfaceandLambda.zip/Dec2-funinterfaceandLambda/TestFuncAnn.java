package com.corejava.funinterfaceandLambda;

public class TestFuncAnn {

    public static void main(String[] args) {

        FuncInterface t = new FuncInterface() {

            public int addNumbers(int a, int b) {
                return ( a + b);
            }
        };

        System.out.println(t.addNumbers(10,50));


    }


}
