package com.corejava.oops;

public class WrapperClassEx {

    public static void main(String[] args) {

    int x = 20;

    //Boxing or wrapping
    //Integer y = new Integer(x);

    // AUtoBoxing....
    Integer y = x;

    //Unboxing
    int z1 = y.intValue();

    // Auto unBoxing / Auto UnWrapping
    int z = y;

        System.out.println(Integer.MIN_VALUE);
        System.out.println(Integer.MAX_VALUE);

        String s = "123";

        // Converting String to int
        int m =Integer.parseInt(s);

        // Converting an int to String
        System.out.println(String.valueOf(m));







    }
}
