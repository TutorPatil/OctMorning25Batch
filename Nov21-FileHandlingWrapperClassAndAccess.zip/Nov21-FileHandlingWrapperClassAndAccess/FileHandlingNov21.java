package com.corejava.oops;

import java.io.*;



public class FileHandlingNov21 {

    public static void main(String[] args) throws IOException {



    }

    public static void fileReaderExample() throws IOException
    {
        File f = new File("D:\\test\\sample.txt");

        FileReader fr = new FileReader(f);
        BufferedReader br = new BufferedReader(fr);

        //System.out.println(br.readLine()); // to read first line..

        // To read the file lineby line need to loop through the whole file...
        String line;
        while ((line = br.readLine()) != null)
        {
            System.out.println(line);
        }

    }


    public static void writeToHtml()throws IOException
    {
        File f = new File("D:\\test\\login.html");
        FileWriter fw = new FileWriter(f,true);

        fw.write("UserName:<input></input>");
        fw.write("<br>");
        fw.write("<br>");
        fw.write("Password:<input></input>");
        fw.write("<br>");
        fw.write("<br>");
        fw.write("<button>Login</button>");

        fw.flush();
        fw.close();
    }

    // writeResultsToFile("TestCase_004","Pass");
    // writeResultsToFile("TestCase_005","Fail");
    public static void writeResultsToFile(String testCaseName, String status)throws IOException
    {
        File f = new File("D:\\test\\sample.txt");
        FileWriter fw = new FileWriter(f,true);

        fw.write(testCaseName +"-----"+status+"\n");

        fw.flush();
        fw.close();

    }

    public static void writeAndAppendToFile() throws IOException
    {
        File f = new File("D:\\test\\sample.txt");
        FileWriter fw = new FileWriter(f,true);

        fw.write("TestCase_001-- Pass \n");
        fw.write("TestCase_002-- Fail \n");
        fw.write("TestCase_003-- Pass \n");
        fw.flush();
        fw.close();
    }

    public static void writeToFile() throws IOException
    {

        File f = new File("D:\\test\\sample.txt");

        FileWriter fw = new FileWriter(f);

        fw.write("Hello World \n");
        fw.write(" Java is very interesting....\n");
        fw.write(" Selenium will be further interesting and easy....\n");

        // It is must to use flush and close methods of filewriter to write & save data to file...
        fw.flush();
        fw.close();
    }


}
