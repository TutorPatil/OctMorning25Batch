package com.corejava.loops;

import com.corejava.oops.Nov21AccessController;

public class TestAccessOutSIdePackageNov21 extends Nov21AccessController {

    public static void main(String[] args) {

        System.out.println(Nov21AccessController.protectedData);
        System.out.println(Nov21AccessController.country);
    }
}
