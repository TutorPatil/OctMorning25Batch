package com.classesobjects;

public class Car {

    int noOfSeats;
    String colour;
    boolean isAutomatic;
    String fuelType;
    static final int noOfTyres = 4;
    CarEngine engine ;
    Thread t;
    static CarEngine cStatic ;


    public void driveCar()
    {
        System.out.println(" The car of the colour "+colour + " which has "+
                noOfSeats + "seats and which is Automatic "+isAutomatic + "fuel type "+fuelType +
                "Whih has an engine of " + engine.engineCC +" is been driven" );
        engine.keepEngineCool();
    }

    public static void fillAirForTyres()
    {
        System.out.println(" The car which has "+noOfTyres + " Needs full air before drive..");
        System.out.println(CarEngine.size);
        cStatic.keepEngineCool();

    }





}
