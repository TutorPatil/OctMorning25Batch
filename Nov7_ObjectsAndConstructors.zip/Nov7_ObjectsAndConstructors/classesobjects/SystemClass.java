package com.classesobjects;

public class SystemClass {

    static String s = "java";
    static PrintStreamClass out = new PrintStreamClass();

}
