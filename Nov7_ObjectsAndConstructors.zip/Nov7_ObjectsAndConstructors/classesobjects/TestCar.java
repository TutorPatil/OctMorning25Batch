package com.classesobjects;

public class TestCar {

    public static void main(String[] args) {

        System.out.println(SystemClass.s.length());

        SystemClass.out.println();


        CarEngine ce =  new CarEngine();
            ce.engineCC = 1500;
            ce.manufacturer = "Toyota";
            ce.needsCoolent = true;


        Car c = new Car();
            c.noOfSeats = 5;
            c.colour = "Grey";
            c.isAutomatic = true;
            c.fuelType = "Petrol";
            c.engine = ce;
            Car.cStatic = ce;

            c.driveCar();

        System.out.println(Car.noOfTyres);
        Car.fillAirForTyres();




    }


}
