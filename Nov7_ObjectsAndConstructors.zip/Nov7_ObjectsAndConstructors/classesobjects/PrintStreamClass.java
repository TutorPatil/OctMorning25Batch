package com.classesobjects;

public class PrintStreamClass {

    public void println()
    {
        System.out.println(" inside the println Methdo...");
    }
}
