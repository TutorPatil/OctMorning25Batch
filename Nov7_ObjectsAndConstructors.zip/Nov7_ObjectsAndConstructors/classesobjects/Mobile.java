package com.classesobjects;

public class Mobile {

    public static String chargingType = "cType";


}
