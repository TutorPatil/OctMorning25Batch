package com.corejava.constructors;


import com.classesobjects.Address_Nov6;

public class Student {

    int id;
    String name;
    int standard;
    boolean transportOpted;
    Address_Nov6 a;

    public Student(int id, String name, int standard, boolean transportOpted, Address_Nov6 a) {
        this.id = id;
        this.name = name;
        this.standard = standard;
        this.transportOpted = transportOpted;
        this.a = a;
    }
    public Student(int id, String name, int standard, boolean transportOpted) {
        this.id = id;
        this.name = name;
        this.standard = standard;
        this.transportOpted = transportOpted;

    }

    // Constructor - default
    public Student()
    {
        System.out.println("Student constructor");
    }



    public void getStudentDetails()
    {
        System.out.println(" The details  student with name "+ name +
                "who has id "+ id + " studying in std "+ standard);
    }


}
