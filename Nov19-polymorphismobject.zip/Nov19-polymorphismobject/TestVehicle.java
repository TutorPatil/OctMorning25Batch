package com.corejava.oops.polymorphismobject;

public class TestVehicle {


    public static void main(String[] args) {

//        Car c = new Car();
//            c.drive();
//            c.fillFuel();
        // ===============================================
//
//        Bike b = new Bike();
//            b.drive();
//            b.fillFuel();
// ===============================================

//        Auto a = new Auto();
//            a.drive();
//            a.fillFuel();

        // ===============================================

        // Parent type reference pointing to child class object..

//        Vehicle v= new Bike();
//            v.drive();
//            v.fillFuel();

        //========================

//        Car c = new Car();
//            c.drive();
//            c.fillFuel();
//            c.driveReverse();

        //===================================

//            Bike b= new Bike();
//                b.drive();
//                b.fillFuel();
//                b.putStand();

         //===========================

        Vehicle v = new Auto();
            v.drive();
            v.fillFuel();
            //v.driveReverse();

        if (v instanceof Car)
        {
            ((Car) v).driveReverse();  // downcasting v to Car level
        }
        if ( v instanceof Bike)
        {
            ((Bike) v).putStand(); // downcasting v to Bike level
        }

        Car c = new Car();
            makeVehicleDrive(c);

         Bike b= new Bike();
            makeVehicleDrive(b);

          Auto a = new Auto();
            makeVehicleDrive(a);


        Vehicle v1  = createObjectAndReturn("Car");
            makeVehicleDrive(v1);

    }

    public static void makeVehicleDrive(Vehicle v)
    {
        v.drive();
        v.fillFuel();
    }


    public static Vehicle createObjectAndReturn(String Objtype)
    {
        Vehicle v = null;
        if(Objtype.equals("Car")) {
             v = new Car();
        }
        if(Objtype.equals("Bike")) {
             v = new Bike();
        }
        return  v;
    }



}
