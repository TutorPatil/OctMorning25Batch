package com.corejava.oops.abstractandinterface;

public class TestVehicle {


    public static void main(String[] args) {

        Ford fordCar = new Ford();
            fordCar.colour = "white";
            fordCar.drive();
            fordCar.park();
            fordCar.dirveReverse();

    }
}
