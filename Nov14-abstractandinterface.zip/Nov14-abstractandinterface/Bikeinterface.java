package com.corejava.oops.abstractandinterface;

public interface Bikeinterface {

    public static final int noOfWheels = 2;

    public abstract void drive();

    void park();

}
