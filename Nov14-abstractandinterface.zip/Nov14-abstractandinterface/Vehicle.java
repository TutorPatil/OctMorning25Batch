package com.corejava.oops.abstractandinterface;

public abstract class Vehicle {

    String colour;

    public abstract void drive();

    public final void park()
    {
        System.out.println("Parking the car of the color "+colour);
    }


}
