package com.corejava.oops.abstractandinterface;

public abstract class Car extends Vehicle{

    public abstract void park();

    public void dirveReverse()
    {
        System.out.println(" The car of the colour "+
                colour +" can be driven in reverse ");

    }

}
