package com.corejava.oops.interfacesobjectclass;

public class TestVehicle {

    public static void main(String[] args) {

        Car c = new Car();
        Car c1 = new Car();
        /*
            c.color = "White";
            c.noOfSets = 4;
            c.isAutomatic = true;
            c.fuelType = "Petrol";

            c.drive();
            c.fillFuel();

            System.out.println("========================");

            c.offerDrive();
            c.startDrive();
            c.endDrive();
            c.checkIdentityBeforeDrive();
            c.offerFreeFirstRide();

            System.out.println("========================");

            c.canJumpAndMakeSound();
            c.canPlayUsingBattery();
*/

        System.out.println("======Object class methods...===");

        System.out.println(c.getClass());

        System.out.println(c.hashCode());

        System.out.println(c1.hashCode());

        c1=c;
        System.out.println(c.hashCode());

        System.out.println(c1.hashCode());


        System.out.println("================");

        System.out.println(c.toString());
        System.out.println(c);










    }


}
