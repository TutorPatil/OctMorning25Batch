package com.corejava.oops.interfacesobjectclass;

public abstract class Vehicle {

    String color;
    boolean isAutomatic;
    int noOfSets;

    public void drive()
    {
        System.out.println(" The vehicle of the colour "+
                color + " which has "+noOfSets +"seats "+
                "which is Automatic "+isAutomatic +" can be driven" );
    }

    public abstract void fillFuel();



}
