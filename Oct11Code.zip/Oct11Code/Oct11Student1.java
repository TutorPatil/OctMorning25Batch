package com.corejava.practice;

public class Oct11Student1 {

    private String name;
    long mobile ;
    double feesPaid;
    private static String course = "Java Selenium";
    boolean isManualTestingDone;
    public static String country = "India";


   public static void printCourseAndCountry()
    {
        final int age = 25;
        System.out.println(age);
        System.out.println(" The course is "+ course + " And the student is from "+ country);
    }

    public void printStudentDetails()
    {
        System.out.println(" The student Name is "+name);
        System.out.println(" The student mobile number is "+mobile);
        System.out.println(" The student has paid the fees of  "+feesPaid);
        System.out.println(" The student completed manual testing course "+isManualTestingDone);
        System.out.println("The course name is"+course);
        System.out.println(" The student country is "+course);
    }

    public static void main(String[] args) {
       printCourseAndCountry();
        Oct11Student1 s1 = new Oct11Student1();
        s1.name = "Rakesh";
        s1.mobile=454541245;
        s1.feesPaid=5000.50;
        s1.isManualTestingDone= true;
        s1.printStudentDetails();

        System.out.println("============================");
        Oct11Student1 s2 = new Oct11Student1();
        s2.name = "Smitha";
        s2.mobile = 78454124;
        s2.feesPaid = 10000.50;
        s2.isManualTestingDone= false;
        s2.printStudentDetails();









    }

}
