package com.corejava.practice;

public class Oct11TestStudent {

    public static void main(String[] args) {

        //System.out.println(" student course is "+Oct11Student.course);
        System.out.println(" The student country  is " +  Oct11Student1.country) ;
        Oct11Student1.printCourseAndCountry();

        Oct11Student1 s3 = new Oct11Student1();
        s3.feesPaid = 4545.05;
    }


}
