package com.java.testing;

import com.corejava.practice.Oct11Student1; // to import a particular class


public class Oct11AccessTest {

    public static void main(String[] args) {

        System.out.println(Oct11Student1.country);
        Oct11Student1 s4 = new Oct11Student1();

        s4.printStudentDetails();
        Oct11Student1.printCourseAndCountry();

    }
}
