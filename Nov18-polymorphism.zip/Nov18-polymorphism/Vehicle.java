package com.corejava.oops.polymorphismobject;

public interface Vehicle {

    public static final int maxSpeed = 200;

    public abstract  void drive();
    public abstract  void fillFuel();

}
