package com.corejava.oops.polymorphismobject;

public class Car implements Vehicle{


    public void drive() {
        System.out.println(" The car can be driven ....");
    }

    public void fillFuel() {
        System.out.println(" The Car can be also parked....");
    }

    public void driveReverse()
    {
        System.out.println(" The car can be driven in reverse direction as well... ....");
    }




}
