package com.corejava.exceptions;



public class TestStudent {

    public static void main(String[] args)  {

        Student s1 = new Student("Rakesh",20);

        //s1.getAdmission();

        //int x = 10/0;

        Student s2 = new Student("Smitha", 5);

        try {
            s2.getAdmission();
        }catch (InvalidAgeException ia){
            ia.printStackTrace();
        }

        System.out.println(" Handled the Inavalid Age exception and now continuing..");



    }

}
