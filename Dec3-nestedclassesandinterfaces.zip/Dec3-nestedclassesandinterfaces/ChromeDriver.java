package com.corejava.nestedclassesandinterfaces;

public class ChromeDriver implements WebDriver,WebDriver.Nested{


    public void get(String url) {
        System.out.println(" Navigating  to the URL "+url);
    }


    public void close() {
        System.out.println("closing the browser");
    }


    public Window manage() {
        return new Window() {
            public void maximize() {
                System.out.println("Maximizing the window...");
            }
        };
    }


    public void testNested() {
        System.out.println("Inside Test Nested Method...");
    }
}
