package com.corejava.nestedclassesandinterfaces;

public class TestNestedClasses {


    public static void main(String[] args) {

        // Creating the object of outer class outside of the class
        Outer out = new Outer();
        System.out.println(out.outerAge);
        out.printOuterAge();

        //Creating the object of inner class out side ( out side)
        Outer.Inner in = out.new Inner();

        Outer.InnerStatic inStat = new Outer.InnerStatic();
        System.out.println(inStat.staticAge);
        System.out.println(inStat.country);
        inStat.printCountry();

        System.out.println(Outer.InnerStatic.country);











    }

}
