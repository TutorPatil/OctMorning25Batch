package com.corejava.nestedclassesandinterfaces;

public interface WebDriver {

    public abstract void get(String url);
    public abstract void close();
    public abstract Window manage();


    interface Window{
        public abstract void maximize();
    }

    static interface Timeout{
        public abstract void implicitlyWait();
    }

    interface Nested{
         void testNested();
    }

}
