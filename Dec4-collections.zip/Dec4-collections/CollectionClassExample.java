package com.corejava.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CollectionClassExample {

    public static void main(String[] args) {

       // List<Integer> al = new ArrayList<>();
       // int[] x = {10,5,8,16,25,100,7};

        List<Integer> al =  Arrays.asList(10,5,8,16,25,100,7);


        System.out.println(al);



        Collections.sort(al);

        System.out.println(al);

        System.out.println(Collections.binarySearch(al,16));

        System.out.println(Collections.min(al));

        System.out.println(Collections.max(al));

        Collections.reverse(al);

        System.out.println(al);

        Collections.shuffle(al);
        System.out.println(al);


      //  Collections.fill(al,20);
        //System.out.println(al);

        List<Integer> al1 = new ArrayList<>(7);
        //Collections.copy(al1,al);
        //System.out.println(al1);




    }
}
