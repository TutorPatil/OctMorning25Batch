package com.corejava.collections;

import java.util.Comparator;

public class Comparator1 implements Comparator<Mobile> {

     public int compare(Mobile o1, Mobile o2) {
        if(o1.ram >o2.ram)
            return -1;
        else
            return 1;

    }
}
